namespace WebApplication1
{
    public class ExperimentDTO
    {
        public string Name { get; set; }
        public int Age { get; set; }
    }
}